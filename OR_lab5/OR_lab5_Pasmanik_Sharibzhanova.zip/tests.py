import time
import genetic_algorythm as alg


def test(file_name, num):
    with open(f'tests\\{file_name}.txt') as f:
        line = f.readline().split(sep=' ')
        m = int(line[0])
        p = int(line[1])
        print(m, p)
        m2p_matrix = [[0 for _ in range(p)] for _ in range(m)]
        for i in range(m):
            line = f.readline().split(sep=' ')
            m_tmp = int(line[0])
            p_tmp = [int(line[i]) for i in range(1,len(line)-1)]
            for j in p_tmp:
                m2p_matrix[m_tmp-1][j-1] = 1
        # for i in range(m):
        #     print(m2p_matrix[i])
        # print()
        ones_count = 0
        p2m_matrix = [[0 for _ in range(m)] for _ in range(p)]
        for i in range(m):
            for j in range(p):
                if m2p_matrix[i][j] == 1:
                    ones_count += 1
                p2m_matrix[j][i] = m2p_matrix[i][j]
        # for i in range(p):
        #     print(p2m_matrix[i])
        p_matrix = [[] for _ in range(p)]
        for i in range(p):
            for j in range(m):
                if p2m_matrix[i][j] == 1:
                    p_matrix[i].append(j)
        # for i in range(m):
        #     print(p_matrix[i])
        st_time = time.time()
        p_res, m_res, score = alg.genetic_algorythm(m2p_matrix,p2m_matrix,p_matrix,p,m,ones_count)
        print(f'TEST   {num}')
        print(f'p_res: {p_res}')
        print(f'm_res: {m_res}')
        print(f'score: {score}')
        print(f'time:  {time.time()-st_time}')

        ans_m = [0 for _ in range(m)]
        for cluster_num, cluster in enumerate(m_res):
            for itm_num in cluster:
                ans_m[itm_num] = cluster_num + 1
        ans_p = [0 for _ in range(p)]
        for cluster_num, cluster in enumerate(p_res):
            for itm_num in cluster:
                ans_p[itm_num] = cluster_num + 1
        with open(f'answers\\{file_name}.sol', 'w') as file:
            for i in ans_m:
                file.write(f'{i} ')
            file.write('\n')
            for i in ans_p:
                file.write(f'{i} ')
