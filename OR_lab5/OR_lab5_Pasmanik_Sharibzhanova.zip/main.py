import tests

tests.test('20x20', 1)
tests.test('24x40', 2)
tests.test('30x50', 3)
tests.test('30x90', 4)
tests.test('37x53', 5)
