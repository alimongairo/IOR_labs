import genetic_algorythm as alg
import tests
import random

# alg.genetic_algorythm(10)

tests.test('20x20.txt', 1)
tests.test('24x40.txt', 2)
tests.test('30x50.txt', 3)
tests.test('30x90.txt', 4)
tests.test('37x53.txt', 5)
