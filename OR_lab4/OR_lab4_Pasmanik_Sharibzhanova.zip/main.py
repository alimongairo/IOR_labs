import tests

print('Local Search\n')
for i in range(1,6):
    tests.test(i, 'ls')
    print()

print('\nIterated Local Search\n')
for i in range(3,6):
    tests.test(i, 'ils')
    print()
