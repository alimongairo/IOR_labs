import random
from collections import Counter


class Bag:
    def __init__(self, w: int, length: int, weights: list, costs: list):
        self.w = w
        self.weights = weights
        self.costs = costs
        self.len = length


class Chromosome:
    def __init__(self, bag: Bag, parents: bool, parent1=None, parent2=None, cross_idx=None):
        self.gens = []
        self.bag = bag

        if parents:
            if parent2 is not None:
                for i in range(parent1.bag.len):
                    if i <= cross_idx:
                        self.gens.append(parent1.gens[i])
                    else:
                        self.gens.append(parent2.gens[i])
            else:
                self.gens = parent1.gens
        else:
            for i in range(self.bag.len):
                self.gens.append(random.randint(0, 1))

        self.total_weight = self.calculate_weight()
        self.total_cost = self.calculate_cost()

    def calculate_weight(self):
        result = 0
        for i in range(len(self.gens)):
            if self.gens[i] == 1:
                result += self.bag.weights[i]
        return result

    def calculate_cost(self):
        result = 0
        for i in range(len(self.gens)):
            if self.gens[i] == 1:
                result += self.bag.costs[i]
        return result

    def check(self):
        self.total_weight = self.calculate_weight()
        while self.total_weight > self.bag.w:
            self.reset_gen()
            self.total_weight = self.calculate_weight()

    def reset_gen(self):
        # l = []
        values = []
        for i in range(self.bag.len):
            if self.gens[i] == 1:
                values.append([self.bag.costs[i] / self.bag.weights[i], i])
        values.sort()
        # rand = random.randint(0, len(l) - 1)
        self.gens[values[0][1]] = 0
        self.total_weight -= self.bag.weights[values[0][1]]
        self.total_cost -= self.bag.costs[values[0][1]]

    def mutation(self):
        chance = 0.001
        for i in range(self.bag.len):
            if random.randint(0, 1000) / 1000 < chance:
                if self.gens[i] == 1:
                    self.gens[i] = 0
                else:
                    self.gens[i] = 1


def crossover(chromosomes, chances, bag):
    new_generation = []
    amount = len(chromosomes)
    new_generation.append(Chromosome(bag=bag, parents=True, parent1=chromosomes[0]))
    new_generation.append(Chromosome(bag=bag, parents=True, parent1=chromosomes[1]))
    for _ in range((amount // 2) - 1):
        parent1, parent2 = random.choices(population=chromosomes[2:], weights=chances[2:], k=2)
        if random.randint(0, 100) < 85:
            cross_idx = random.randint(0, bag.len)
            new_generation.append(
                Chromosome(bag=bag, parents=True, parent1=parent1, parent2=parent2, cross_idx=cross_idx))
            new_generation.append(
                Chromosome(bag=bag, parents=True, parent1=parent2, parent2=parent1, cross_idx=cross_idx))
        else:
            new_generation.append(Chromosome(bag=bag, parents=True, parent1=parent1))
            new_generation.append(Chromosome(bag=bag, parents=True, parent1=parent2))
    if amount % 2 == 1:
        new_generation.append(chromosomes[-1])
    return new_generation


def check_4_exit(chromosomes, total):
    tmp = []
    for itm in chromosomes:
        tmp.append(str(itm.gens))
    count = Counter(tmp)
    for c in count.values():
        if c / total >= 0.6:
            return True
    return False


def selection_chances(chromosomes):
    chances = []
    group1, group2, group3, group4 = [], [], [], []
    for i in range(len(chromosomes)):
        if i <= len(chromosomes) / 4:
            group1.append(chromosomes[i])
        elif i <= len(chromosomes) / 2:
            group2.append(chromosomes[i])
        elif i <= 3 * len(chromosomes) / 4:
            group3.append(chromosomes[i])
        else:
            group4.append(chromosomes[i])
    for _ in group1:
        chances.append(0.5 / len(group1))
    for _ in group2:
        chances.append(0.3 / len(group2))
    for _ in group3:
        chances.append(0.15 / len(group3))
    for _ in group4:
        chances.append(0.05 / len(group4))
    return chances


def genetic_algorythm(w, weights, costs):
    bag = Bag(w=w, length=len(weights), weights=weights, costs=costs)

    count_of_chromosomes = 250
    chromosomes = [Chromosome(parents=False, bag=bag) for _ in range(count_of_chromosomes)]

    for chromosome in chromosomes:
        chromosome.check()

    chromosomes.sort(key=lambda x: x.calculate_cost(), reverse=True)

    for _ in range(100):
        chances = selection_chances(chromosomes=chromosomes)
        chromosomes = crossover(chromosomes=chromosomes, chances=chances, bag=bag)
        for chrom in chromosomes:
            chrom.mutation()

        for chromosome in chromosomes:
            chromosome.check()

        chromosomes.sort(key=lambda x: x.total_cost, reverse=True)

        if check_4_exit(chromosomes, count_of_chromosomes):
            break

    return chromosomes[0].gens, chromosomes[0].total_cost, chromosomes[0].total_weight
