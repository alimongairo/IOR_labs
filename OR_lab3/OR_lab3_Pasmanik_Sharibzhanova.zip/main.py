import knapsack_tests
import hamilton_tests

print('KNAPSACK')
for i in range(1,8):
    knapsack_tests.test(i)

print('TSP')
for i in range(1,7):
    hamilton_tests.test(i)
